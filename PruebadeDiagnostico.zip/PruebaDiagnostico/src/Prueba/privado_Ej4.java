package Prueba;

public class privado_Ej4 extends Empleado_Ej4{

	private String comuna;
	private String empresa;
	
	public privado_Ej4() {
		super();
	}

	public privado_Ej4(String RUT, String nombre, String apellidos, String direccion, int telefono, double sueldo,
			String comuna, String empresa) {
		super(RUT, nombre, apellidos, direccion, telefono, sueldo);
		this.comuna = comuna;
		this.empresa = empresa;
	}

	public String getComuna() {
		return comuna;
	}

	public void setComuna(String comuna) {
		this.comuna = comuna;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	
	
	
}
