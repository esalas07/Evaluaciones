
package Prueba;

import java.util.Scanner;

public class biotren {


        public static void main (String[] args){

       
        Scanner entrada = new Scanner(System.in);		
        int numerotarjeta = 0;
		double viaje;
		int rut;
		int tipodeusuario = 0;
		double saldo = 0;
		int saldo1;
		double descuento;
		int respuesta1,respuesta2,respuesta3;
		int kilometros;
		double viajefinal;
		respuesta1=0;
		respuesta2=0;
		respuesta3=0;	
     
          while (respuesta1!=4);  {
            
           System.out.println("1.- Crear nuevo usuario");
           System.out.println("2.- Realizar Abono ");
           System.out.println("3.- Realizar un viaje");
           System.out.println("4.- Salir");
           respuesta1 = entrada.nextInt();
           
           if(respuesta1==4){
                 System.out.println("Sesion finalizada");
               
           }
           
           
          switch (respuesta1){
              
              case 1:
              
                System.out.println("Ingrese tipo de usuario");
                System.out.println("1.- Comun  2.- TNE  3.- Bip");
                tipodeusuario = entrada.nextInt();
                  
                  switch (tipodeusuario){
                        
                      case 1:
                           System.out.println("Ingrese su RUT");
                           numerotarjeta=entrada.nextInt();
                           System.out.println("Ingrese saldo1");
                           saldo1=entrada.nextInt();
                           break;
                          
                      case 2:
                           System.out.println("Ingrese su RUT");
                           numerotarjeta=entrada.nextInt();
                           System.out.println("Ingrese saldo1");
                           saldo1=entrada.nextInt();
                           break;    
                       
                       case 3:
                           System.out.println("Ingrese su RUT");
                           numerotarjeta=entrada.nextInt();
                           System.out.println("Ingrese saldo1");
                           saldo1=entrada.nextInt();
                           break;    
                            
          }
                  
                           break;
                  
               case 2:
              
                System.out.println("�Usted tiene cuenta de Biotren?");
                System.out.println("1.- Si, 2.- No");
                respuesta2 = entrada.nextInt();    
                   
                   switch(respuesta2){
                       
                       case 1: 
                        System.out.println("Ingrese su RUT");   
                        rut=entrada.nextInt();   
                           
                           if(rut==numerotarjeta){
                               
                               System.out.println("Bienvenido, �cuanto abonara a su cuenta?");   
                               saldo1=entrada.nextInt(); 
                               saldo=(saldo1+saldo);
                               System.out.println("Su nuevo saldo es: "+saldo);
                               
                           }
                           else{
                               System.out.println("Usted no tiene cuenta de Biotren"); 
                           }
                           break;
                           
                       case 2:
                        System.out.println("Volver al menu principal");    
                         break;
                   }
                        break;
                       case 3: 
                        System.out.println("�Usted desea viajar?");   
                        System.out.println("�Usted tiene cuenta de Biotren?");    
                        System.out.println("1.- Si, 2.- No");
                        respuesta3 = entrada.nextInt();    
                      
                        switch(respuesta3){  
                           
                        case 1:	    			
                        System.out.println("ingrese su RUT");
	    	        rut = entrada.nextInt();	    		
                        if (rut==numerotarjeta) {	    	
		        System.out.println("bienvenido, �cuantos kilometros desea viajar?");	    	
	    	        System.out.println("Costo por kilometro = $100 pesos");	    		
                  	kilometros = entrada.nextInt();	    		
                  	viaje =(kilometros*100);
	    		
                	if (tipodeusuario==1) {	    		
                        	descuento = (viaje*0.05);	    		
                          	viajefinal =(viaje-descuento);	    			
                                 saldo=(saldo-viajefinal);	    		
                      	if (viajefinal>saldo) {	    			
                          	System.out.println("Ud no Dispone de saldo suficiente para este viaje");
	    		        System.out.println("Volver al menu Principal");    				
}	    			else {	    	
                    		System.out.println("El costo de su viaje es de: "+viajefinal+" y su descuento por ser un usuario tipo Comun fue de "+descuento);
	    			System.out.println("Su nuevo Saldo es: "+saldo);	
	    			System.out.println("Volver al menu Principal");
	    		}
	    			}		
	    			if (tipodeusuario==2) {		    
              			descuento = (viaje*0.10);		   
   	 		        viajefinal =(viaje-descuento);		
    	          		saldo=(saldo-viajefinal);		    	
          		if (viajefinal>saldo) {		    	
               			System.out.println("Ud no Dispone de saldo suficiente para este viaje");
		    		System.out.println("Volver al menu Principal");	    		
		}		    			else {		    
			        System.out.println("El costo de su viaje es de: "+viajefinal+" y su descuento por ser un usuario tipo TNE fue de "+descuento);
		    		System.out.println("Su nuevo Saldo es: "+saldo);	
		    		System.out.println("Volver al menu Principal");
		    		}
	    			}
                                if (tipodeusuario==3) {	
	    			descuento = (viaje*0.20);		
    			        viajefinal =(viaje-descuento);		    	
		                saldo=(saldo-viajefinal);		  
         			if (viajefinal>saldo) {		    		
                  		System.out.println("Ud no Dispone de saldo suficiente para este viaje");
		    	        System.out.println("Volver al menu Principal");	    	
			}		    			else {		    
              			System.out.println("El costo de su viaje es de: "+viajefinal+" y su descuento por ser un usuario tipo Bip fue de "+descuento);
		    		System.out.println("Su nuevo Saldo es: "+saldo);
		    		System.out.println("Volver al menu Principal");
		    		}        
            }
	    		break;	    		
}	    		case 2:	    		
	                        System.out.println("Volver al menu Principal");	  
  	         	break;	 	   
                            
                            
                            
                            
                   }
              
                   
          }
           
        }
            
  
        }
}

    

