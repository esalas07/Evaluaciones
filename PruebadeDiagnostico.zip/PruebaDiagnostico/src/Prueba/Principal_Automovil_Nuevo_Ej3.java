package Prueba;



import javax.swing.JOptionPane;



public class Principal_Automovil_Nuevo_Ej3 {

	
	public static void main(String[] args) {
		
	
	Automovil_Nuevo_Ej3 A1= new Automovil_Nuevo_Ej3();

 
	A1.setMarca(JOptionPane.showInputDialog(null, "Ingrese Marca"));
	A1.setModelo(JOptionPane.showInputDialog(null, "Ingrese Modelo"));
	A1.setA�o(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese A�o")));
    A1.setPrecio(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese Precio")));
    A1.Preciofinal();
    
    JOptionPane.showMessageDialog(null,"La Marca es:  " +A1.getMarca()+ "\n El Modelo es:   " +A1.getModelo()+ "\n El A�o es:  " +A1.getA�o()+ "\n  El precio final es:" +A1.getPrecio() );

	
	
	}
	
	
}
