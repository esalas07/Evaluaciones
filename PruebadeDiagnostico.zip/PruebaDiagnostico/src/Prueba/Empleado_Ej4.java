package Prueba;

public class Empleado_Ej4 {

	private String RUT;
	private String Nombre;
	private String Apellidos;
	private String Direccion;
	private int Telefono;
	private double Sueldo;
	
	public Empleado_Ej4() {
		super();
	}

	public Empleado_Ej4(String RUT, String nombre, String apellidos, String direccion, int telefono, double sueldo) {
		super();
		RUT = RUT;
		Nombre = nombre;
		Apellidos = apellidos;
		Direccion = direccion;
		Telefono = telefono;
		Sueldo = sueldo;
	}

	public String getRUT() {
		return RUT;
	}

	public void setRUT(String RUT) {
		RUT = RUT;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellidos() {
		return Apellidos;
	}

	public void setApellidos(String apellido) {
		Apellidos = Apellidos;
	}

	public String getDireccion() {
		return Direccion;
	}

	public void setDireccion(String direccion) {
		Direccion = direccion;
	}

	public int getTelefono() {
		return Telefono;
	}

	public void setTelefono(int telefono) {
		Telefono = telefono;
	}

	public double getSueldo() {
		return Sueldo;
	}

	public void setSueldo(double sueldo) {
		Sueldo = sueldo;
	}
	
	
	
	
}
