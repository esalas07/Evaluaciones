package Prueba;


import javax.swing.JOptionPane;

public class PrincipalEmpleado_Ej2 {

	
	public static void main(String[] args) {
		
		
		Empleado_Ej2 E1= new Empleado_Ej2();

	 
		E1.setRut(JOptionPane.showInputDialog(null, "Ingrese rut"));
		E1.setCargo(JOptionPane.showInputDialog(null, "Ingrese cargo"));
		E1.setNombre(JOptionPane.showInputDialog(null, "Ingrese nombre"));
		E1.setApellidop(JOptionPane.showInputDialog(null, "Ingrese apellidop"));
		E1.setApellidom(JOptionPane.showInputDialog(null, "Ingrese apellidom"));
		
		JOptionPane.showMessageDialog(null,"El rut es:  " +E1.getRut()+ "\n El cargo es:   " +E1.getCargo()+ "\n El nombre es:  " +E1.getNombre()+ "\n  El apellidop es:" +E1.getApellidop()+ "\n  El apellidom es:" +E1.getApellidom() );
		
		
		
		E1.setRut(JOptionPane.showInputDialog(null, "Ingrese rut"));
		E1.setApellidop(JOptionPane.showInputDialog(null, "Ingrese apellidop"));
		E1.setApellidom(JOptionPane.showInputDialog(null, "Ingrese apellidom"));
		E1.setDireccion(JOptionPane.showInputDialog(null, "Ingrese direccion"));
		E1.setFono(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese fono")));
		E1.setEmail(JOptionPane.showInputDialog(null, "Ingrese email"));
	    
	    JOptionPane.showMessageDialog(null,"El rut es:" +E1.getRut()+  "\n El apellidop es:   " +E1.getApellidop()+ "\n El apellidom es:  " +E1.getApellidom()+ "\n  La direccion es:" +E1.getDireccion()+ "\n  El fono es:" +E1.getFono()+ "\n  El email es:" +E1.getEmail());

		
		
		}
	
	
	
}
