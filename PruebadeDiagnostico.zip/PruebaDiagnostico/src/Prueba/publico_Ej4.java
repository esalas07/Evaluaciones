package Prueba;

public class publico_Ej4 extends Empleado_Ej4{

	private String municipalidad;
	private String departamento;
	public publico_Ej4() {
		super();
	}
	public publico_Ej4(String RUT, String nombre, String apellidos, String direccion, int telefono, double sueldo,
			String municipalidad, String departamento) {
		super(RUT, nombre, apellidos, direccion, telefono, sueldo);
		this.municipalidad = municipalidad;
		this.departamento = departamento;
	}
	public String getMunicipalidad() {
		return municipalidad;
	}
	public void setMunicipalidad(String municipalidad) {
		this.municipalidad = municipalidad;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	
	
	
}
