package Prueba;


import java.util.Scanner;

import Clase05FebreroAlimentos.ProductoCongelado;
import Clase05FebreroAlimentos.ProductoFresco;
import Clase05FebreroAlimentos.ProductoRefrigerado;

public class PersonaEj_4 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	

		
		publico_Ej4 EP = new publico_Ej4("15.242.3566","Fernando","Mellado Salinas","Los Laureles 45", 945281947, 780000, "Municipalidad de Los Alamos" , "Administrativo");
	    privado_Ej4 EPR = new privado_Ej4("12.345.6787","Francisco","Risopatron de Lourdes","Juan Bosco 1786", 976834616,6000000,"Comuna Las Condes" ,"Gerencia");
		
  

    	System.out.println("El RUT del empleado publico es:  ");
    	System.out.println(EP.getRUT());
   
    	
    	System.out.println("El nombre del empleado publico es:  ");
    	System.out.println(EP.getNombre());
   
    	
    	System.out.println("Los Apellidos del empleado publico son:  ");
    	System.out.println(EP.getApellidos());
		
    	
    	System.out.println("La Direccion del empleado publico es:  ");
    	System.out.println(EP.getDireccion());
    	
    	
    	System.out.println("El Telefono del empleado publico es:  ");
    	System.out.println(EP.getTelefono());
    	
    	
    	System.out.println("El Sueldo del empleado publico es:  ");
    	System.out.println(EP.getSueldo());
    	
    	
    	System.out.println("La Municipalidad del empleado publico es:  ");
    	System.out.println(EP.getMunicipalidad());
    	
    	
    	System.out.println("El Departamento del empleado publico es:  ");
    	System.out.println(EP.getDepartamento());
    	
    	
    	System.out.println("El RUT del empleado privado es:  ");
    	System.out.println(EPR.getRUT());
   
    	
    	System.out.println("El nombre del empleado privado es:  ");
    	System.out.println(EPR.getNombre());
   
    	
    	System.out.println("Los Apellidos del empleado privado son:  ");
    	System.out.println(EPR.getApellidos());
		
    	
    	System.out.println("La Direccion del empleado privado es:  ");
    	System.out.println(EPR.getDireccion());
    	
    	
    	System.out.println("El Telefono del empleado privado es:  ");
    	System.out.println(EPR.getTelefono());
    	
    	
    	System.out.println("El Sueldo del empleado privado es:  ");
    	System.out.println(EPR.getSueldo());
    	
    	
    	System.out.println("La Comuna del empleado privado es:  ");
    	System.out.println(EPR.getComuna());
    	
    	
    	System.out.println("La Empresa del empleado privado es:  ");
    	System.out.println(EPR.getEmpresa());
    	  	
    	
}
}
