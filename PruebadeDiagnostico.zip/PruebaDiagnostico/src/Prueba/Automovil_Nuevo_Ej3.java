package Prueba;

public class Automovil_Nuevo_Ej3 {

	private String Marca;
	private String Modelo;
	private int A�o;
	private double Precio;
	
	
	public Automovil_Nuevo_Ej3() {
		super();
	}

	

	public Automovil_Nuevo_Ej3(String marca, String modelo, int a�o, double precio) {
		super();
		Marca = marca;
		Modelo = modelo;
		A�o = a�o;
		Precio = precio;
	}

	
	
	public String getMarca() {
		return Marca;
	}



	public void setMarca(String marca) {
		Marca = marca;
	}



	public String getModelo() {
		return Modelo;
	}



	public void setModelo(String modelo) {
		Modelo = modelo;
	}



	public int getA�o() {
		return A�o;
	}



	public void setA�o(int a�o) {
		A�o = a�o;
	}



	public double getPrecio() {
		return Precio;
	}



	public void setPrecio(double precio) {
		Precio = precio;
	}


	public void Preciofinal () {
		
		setPrecio(Precio + (0.19*Precio)+(0.05*Precio)+100000);
	
	
	
	}
	
}
