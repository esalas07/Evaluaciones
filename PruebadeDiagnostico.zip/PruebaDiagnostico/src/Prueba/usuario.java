
package Prueba;

public class usuario {
    
    private int numero_tarjeta;
    private double viaje;
    private int RUT;
    private int tipo_usuario;
    private double saldo;
    private int saldo1;
    private double descuento;
    private int respuesta1,respuesta2,respuesta3;
    private int kilometros;
    private double viaje_final;

    public usuario() {
        super();
    }

    public usuario(int numero_tarjeta, double viaje, int RUT, int tipo_usuario, double saldo, int saldo1, double descuento, int respuesta1, int respuesta2, int respuesta3, int kilometros, double viaje_final) {
        this.numero_tarjeta = numero_tarjeta;
        this.viaje = viaje;
        this.RUT = RUT;
        this.tipo_usuario = tipo_usuario;
        this.saldo = saldo;
        this.saldo1 = saldo1;
        this.descuento = descuento;
        this.respuesta1 = respuesta1;
        this.respuesta2 = respuesta2;
        this.respuesta3 = respuesta3;
        this.kilometros = kilometros;
        this.viaje_final = viaje_final;
    }

    public int getNumero_tarjeta() {
        return numero_tarjeta;
    }

    public void setNumero_tarjeta(int numero_tarjeta) {
        this.numero_tarjeta = numero_tarjeta;
    }

    public double getViaje() {
        return viaje;
    }

    public void setViaje(double viaje) {
        this.viaje = viaje;
    }

    public int getRUT() {
        return RUT;
    }

    public void setRUT(int RUT) {
        this.RUT = RUT;
    }

    public int getTipo_usuario() {
        return tipo_usuario;
    }

    public void setTipo_usuario(int tipo_usuario) {
        this.tipo_usuario = tipo_usuario;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getSaldo1() {
        return saldo1;
    }

    public void setSaldo1(int saldo1) {
        this.saldo1 = saldo1;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public int getRespuesta1() {
        return respuesta1;
    }

    public void setRespuesta1(int respuesta1) {
        this.respuesta1 = respuesta1;
    }

    public int getRespuesta2() {
        return respuesta2;
    }

    public void setRespuesta2(int respuesta2) {
        this.respuesta2 = respuesta2;
    }

    public int getRespuesta3() {
        return respuesta3;
    }

    public void setRespuesta3(int respuesta3) {
        this.respuesta3 = respuesta3;
    }

    public int getKilometros() {
        return kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public double getViaje_final() {
        return viaje_final;
    }

    public void setViaje_final(double viaje_final) {
        this.viaje_final = viaje_final;
    }
    
    

    
    
    
}
