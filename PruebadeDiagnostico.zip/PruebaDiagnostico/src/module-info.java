module PruebaDiagnostico {
	requires java.desktop;
}